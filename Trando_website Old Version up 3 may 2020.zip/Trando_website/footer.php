<div id="base" class="container-fluid">
    <div class="container ">
       <div class="text-center Social_acc">
          <a href="https://www.facebook.com/TrandoTeam/?modal=admin_todo_tour"> <span class="fa fa-facebook-square fb" id="mar" style="color:#3b5998 ;"></span></a>
          <a href="#"><span class="fa fa-instagram ins" id="mar" style="color:tomato;"></span></a>
          <a href="#"> <span class="fa fa-linkedin-square in" id="mar" style="color:#0e76a8  ;" ></span></a>
       </div>
      
       <div class="container text-center " style="margin-top: 20px;" >
        <h3 class="" style="font-family:'Martel';">Contact Details</h3>
        <p style="font-family:'Tinos:400'">
            <span class="fa fa-phone">  Mobile Number:</span>9027997165
            <br>
            <span class="fa fa-envelope"> Email:</span>
            <a href="mailto:query.trando@gmail.com"> query@trando.in</a>
            <br>
            <span class="fa fa-link">Website:</span>
            <a href="http://www.Trando.in"> www.Trando.in</a>
        </p>
        
    </div>
           
           
            <div class="clearfix"></div>