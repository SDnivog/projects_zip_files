<!DOCTYPE html>
<html>
<head>
	<title>Trando</title>
	<meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="author" content="Trando">
    <meta name="description" content="Trando is a platform to help you in uplifting your Business.We in 'Trando' will help you in improving your business by providing our best services. Let's come together and give wings to your business .">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel = "icon" href ="images/logo icon.png"
        type = "image/x-icon">
    <link rel="stylesheet" href="css/style1.css">
    <link rel="stylesheet" href="css/Style.css">
    <link rel="stylesheet" href="css/service.css">
    <link rel="stylesheet"
    href="https://cdn.jsdelivr.net/npm/animate.css@3.5.2/animate.min.css">
    <!-- or -->
    <link rel="stylesheet"
    href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/3.5.2/animate.min.css">
    <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
   
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
   
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link href='https://fonts.googleapis.com/css?family=Cabin Sketch' rel='stylesheet'>
 
 
  <script src="https://cdnjs.cloudflare.com/ajax/libs/typed.js/2.0.8/typed.min.js"></script>
  <link href="https://fonts.googleapis.com/css?family=Josefin+Slab:600&display=swap" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css?family=Gloria+Hallelujah&display=swap" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css?family=Karla|Yeon+Sung|Tinos:700,400|Overlock:900|Bitter|Bungee|Martel|Roboto+Condensed|Acme|Cinzel|Muli|Pacifico|Simonetta&display=swap" rel="stylesheet">
</head>
<body>
	<!---INCLUDING HEADER ----->
  <?php include('header.php') ?>
 <!---INCLUDING HOMEPAGE --->
 <?php include('home.php') ?>


<!--INCLUDING FOOTER ---->
<?php include('footer.php') ?>



 <script src="js/index.js"></script>
 <script src="js/hover.js"></script>
 <script src="js/animate.js"></script>
</body>
</html>