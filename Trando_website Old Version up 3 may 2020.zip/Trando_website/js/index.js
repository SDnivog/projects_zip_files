// function made(num)
// {
//   for(let i=1;i<=4;i++){
//     if(num != i){
//       document.getElementById('content'+i).style.display="none";
//       document.getElementById("header"+i).style.color="white";
//      document.getElementById("header"+i).style.borderBottom="none";
    
      
//     }
//     else {
//       document.getElementById('content'+num).style.display="block";
//       document.getElementById("header"+num).style.color="tomato";
//       document.getElementById("header"+num).style.paddingBottom="25px";
//       if(screen.width >=700){
//       document.getElementById("header"+num).style.borderBottom="5px solid tomato";
//       }
//       else{
//         document.getElementById("header"+num).style.borderBottom="none";
//       }      
//     }
//   }
// }
function col(x)
{
 document.getElementById("co"+x).style.boxShadow="none";
}
function col1(z)
{
 document.getElementById("co"+z).style.boxShadow="0 10px 10px 0 rgba(0,0,0,0.8)";
}

function Scroll()
{
  var top = document.getElementById("header");
  // var logo = document.getElementById('logo');
  var ypos = parseInt(window.pageYOffset);
  // var i = 125; 
  // var j=0.2;
 
if(ypos >0 && ypos<100) 
  { 
    top.style.height = "100px";
    top.style.backgroundColor="rgba(0,0,0,0.3)";
    // logo.style.height="120%";
  }
   else if(ypos >100 && ypos<150){
    top.style.height = "96px";
    top.style.backgroundColor="rgba(0,0,0,0.4)";
    // logo.style.height="125%";
  

  }
  else if(ypos >150 && ypos<200){
    top.style.height = "94px";
    top.style.backgroundColor="rgba(0,0,0,0.5)";
    // logo.style.height="130%";
  

  }
  else if(ypos >200 && ypos<250){
    top.style.height = "91px";
    top.style.backgroundColor="rgba(0,0,0,0.6)";
    // logo.style.height="135%";
  

  }
  else if(ypos >250 && ypos<300){
    top.style.height = "88px";
    top.style.backgroundColor="rgba(0,0,0,0.7)";
    // logo.style.height="140%";
  

  }
  else if(ypos >300 && ypos<350){
    top.style.height = "85px";
    top.style.backgroundColor="rgba(0,0,0,0.8)";
    // logo.style.height="150%";
  }
  else if(ypos >350 && ypos<400){
    top.style.height = "82px";
    top.style.backgroundColor="rgba(0,0,0,0.9)";
    // logo.style.height="160%";
  }
   else if(ypos>400){
    top.style.height = "79px";
    top.style.backgroundColor="rgba(0,0,0,1)";
    // logo.style.height="180%";
    

  }
 else
  {
   top.style.height = "100px";
   top.style.backgroundColor="rgba(0,0,0,0.4)";
  //  logo.style.height="auto";
  }

 }
window.addEventListener("scroll",Scroll);


new Typed('#typed',{
  strings : ['So what are you Looking for ?','Web Development','Digital Marketing','Data Analyst','Android App '],
  typeSpeed : 100,
  delaySpeed : 1000,
  loop : true
});

window.onresize=function(){
  if(window.innerWidth >670){
    this.document.getElementById('mains').style.display="block";
    window.location.reload();



  }
  else{
    for(let i=1;i<=3; i++)
    document.getElementById('header'+i).style.borderBottom="none";
  }
}