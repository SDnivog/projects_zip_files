/* mobile view */

function show(){
    var s = document.getElementById('mains');
    if(s.style.display == "block"){
        s.style.display ="none" 
    }
    else{
        s.style.display ="block"
    }
}


function  nxt(){
    
}