$(document).ready(function(){
    $(window).scroll(function(){
    var pos= $(document).scrollTop();
    // alert(pos);
    
    if(pos>300 && pos<400){
    $('#service_left1').addClass("animated slideInRight");
    }
    if(pos>950 && pos<1100){
      $('#service_right1').addClass("animated slideInLeft");
    }
    if(pos>1650 && pos<1800){
        $('#service_left2').addClass("animated slideInRight");
    }
    if(pos>2500 && pos<2700){
      $('#service_right2').addClass("animated slideInLeft");
    }
    if(pos>3350 && pos<3500){
      $('#service_left3').addClass("animated slideInRight");
  }
    if(pos>4200 && pos<4400){
      $('#service_right3').addClass("animated slideInLeft");
    }
    if(pos>5050 && pos<5200){
      $('#service_left4').addClass("animated slideInRight");
  }
    if(pos>5900 && pos<6100){
      $('#service_right4').addClass("animated slideInLeft");
    }
   
    });


});

// function c(x){
// document.getElementById("sli"+x ).style.display="block";
// }

// function co(x){
// document.getElementById("sli"+x ).style.display="none";
// }

//  function web(x){
//   document.getElementById("gone"+x).style.display="none";
//   document.getElementById("data"+x).style.display="block";
//   document.getElementById("data"+x).className="animated rotateInDownRight";
//   document.getElementById("webhed"+x).style.color="tomato";
//   document.getElementById("webhed"+x).style.borderBottom="2px solid tomato";
// }

// function web1(x){

//   document.getElementById("data"+x).style.display="none";
//   document.getElementById("gone"+x).style.display="block";
//   document.getElementById("gone"+x).className="animated rotateInDownLeft";
//   document.getElementById("gone"+x).className="animated fast";
//   document.getElementById("webhed"+x).style.color="white";
//   document.getElementById("webhed"+x).style.borderBottom="none";
//   // document.getElementsById("service_image1").style.height="373px";
// }
