function col(x){
document.getElementById("co"+x).style.boxShadow="0px 7px 0px 0px rgba(135,206,235,0.5)";

}


function cols(x){
document.getElementById("co"+x).style.boxShadow="none";

}

function fun(){

  document.getElementById("fle").style.display="none";
  document.getElementById("fle1").style.display="block";
  document.getElementById("f1").innerHTML="Already Have a Account ? <span id='signup' onclick='fun2()'>Log In</span>";
  document.getElementById("top").innerHTML="Sign Up With Trando";
}

function fun2(){
  document.getElementById("fle").style.display="block";
  document.getElementById("fle1").style.display="none";
  document.getElementById("f1").innerHTML="New To Trando ? <span id='signup' onclick='fun()'>Sign Up</span>";
  document.getElementById("top").innerHTML="Login With Trando";

}
function sh()
  {
    let s = document.getElementById("co2");
    let shows = document.getElementById("show1"); 
    if(shows.className=="glyphicon glyphicon-eye-close")
    {
      s.type="text";
      shows.className="glyphicon glyphicon-eye-open";
    }
    else{
      s.type="password";
      shows.className="glyphicon glyphicon-eye-close";
  
    }
  }
