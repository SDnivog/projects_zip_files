    <div id="content1">
    <div class="hoimg w3-card-2 text-center ">
        <div class="" style="padding-top: 130px;">
            <div>
                <h1><span id="typed"></span></h1>
              </div>            
  <img src="images/hr.png" alt="" style="max-width: 100%;">
        </div>
        <div class="container-fluid">
        <div class="col-sm-9 ">

        </div>
       
        <div class="cot col-sm-3 w3-card-4" >
<ul>
    <li> Are you Looking for <br> Web Designing ?</li>
    <li> Is your Data <br> important for You ?</li>
    <li> Enhance your Bussiness with <br> Creative Design</li>
</ul>
        </div>
        </div>
  
    </div>

             <div class="container" style="background-color: rgb(255, 255, 255);">
                <!--Cast Here the deatils of Feature-->

          <div class="container-fluid" style="height:auto;">
              <section class="">
                <h1 class="text-center about">About Services</h1>
                <div class="text-center" style="margin: 10px;">
                    <img src="images/hr.png" alt="" style="max-width: 100%;">
                  </div>
        <div class="col-sm-9" style="padding: 20px;">
        <p id="first">Trando is a platform to help you in uplifting your Business. We are providing different business improving services. Since motive of each and every step taken by you in your business is to improve it and take it to a next level. We in 'Trando' will help you in improving your business by providing our best services. Let's come together and give wings to your business . </p>
        <div class="container-fluid thumbnail"  >
        <div id="carouselExampleIndicators" class="carousel slide" data-ride="carousel" style="background-color: rgb(255, 255, 255);" >
        
            <!-- Wrapper for slides -->
            <div class=" carousel-inner " style="height: auto;">
              <div class="item active">
                <img id="im" src="images/6.jpg" alt="Los Angeles" >
                <div  class="carousel-caption">
                    <h1 id="md">Web Development</h1>
                </div>
              </div>
          
              <div class="item">
                <img id="im" src="images/81.jpg" alt="Chicago">
                <div class="carousel-caption">
                   <h1 id="md">Android App</h1>
                </div>
              </div>
          
              <div class="item">
                <img id="im" src="images/71.jpg" alt="New York">
                <div class="carousel-caption">
                    <h1 ></h1>
                                    </div>
              </div>
              <div class="item">
                <img id="im" src="images/31.jpg" alt="New York">
                <div class="carousel-caption">
                    <h1 id="md">Data Computing</h1>
                                    </div>
              </div>
              <div class="item">
                <img id="im" src=" images/21.jpg" alt="New York">
                <div class="carousel-caption">
                    <h1 id="md">Data Analysis</h1>
                                    </div>
              </div>
              <div class="item">
                <img id="im" src="images/p12.jpg" alt="New York">
                <div class="carousel-caption">
                    <h1 id="md">Photoshop</h1>
                                    </div>
              </div>
              <div class="item">
                <img id="im" src="images/51.jpg" alt="New York">
                <div class="carousel-caption">
                    <h1></h1>
                                    </div>
              </div>
            </div>
          
            <!-- Left and right controls -->
            <a class="left carousel-control" href="#carouselExampleIndicators" data-slide="prev">
              <span class="glyphicon glyphicon-chevron-left"></span>
              <span class="sr-only">Previous</span>
            </a>
            <a class="right carousel-control" href="#carouselExampleIndicators" data-slide="next">
              <span class="glyphicon glyphicon-chevron-right"></span>
              <span class="sr-only">Next</span>
            </a>
          </div></div>
        </div>
        <div class="col-sm-3" id="left" >
        <h2 style="font-family: fantasy;color: grey;" class="well">Why Us?</h2>
        <ul class="list-unstyled " style="font-size: larger;">
            <li class="why_opt"><span class="glyphicon glyphicon-chevron-right" style="color: black;"></span> Work According to Your choice</li>
        <li class="why_opt"><span class="glyphicon glyphicon-chevron-right" style="color: black;"></span> Super Clean Code</li>
        <li class="why_opt"><span class="glyphicon glyphicon-chevron-right" style="color: black;"></span> Best Forecaster</li>
        <li class="why_opt"><span class="glyphicon glyphicon-chevron-right" style="color: black;"></span> Experts in Courses</li>
        <li class="why_opt"><span class="glyphicon glyphicon-chevron-right" style="color: black;"></span> Digital Marketing according to your Business</li>
        <li class="why_opt"><span class="glyphicon glyphicon-chevron-right" style="color: black;"></span> Clean Data Computing</li>
        <li class="why_opt"><span class="glyphicon glyphicon-chevron-right" style="color: black;"></span> Satisfy Customers </li>
        <li class="why_opt"><span class="glyphicon glyphicon-chevron-right" style="color: black;"></span> Posters for Business</li>
        <li class="why_opt"><span class="glyphicon glyphicon-chevron-right" style="color: black;"></span> Economical</li>
        <li class="why_opt"><span class="glyphicon glyphicon-chevron-right" style="color: black;"></span> Work on Time</li>
        </ul>


        </div>
              </section>
             <div class="text-center container-fluid" style="margin-bottom: 10px;">
                <img  src="images/hr.png" alt="" style="max-width: 100%;">
             </div>
              <div class="container-fluid">
               
<div class="container heading">
    <div class="col-md-4" id="con1" >
         <div class="text-center ">
            <i id="ic" class=" fa fa-check" aria-hidden="true"></i><h3 style="font-size: 25px;font-family: 'Simonetta';font-weight:bolder;" > You are at a Right Platform</h3>
        <p style="text-align: justify;">Every Service has been taken into consideration before providing and hence, we have experts. We take care of our Customer's Requirement. </p>
        <img src="images/hr.png" alt="" style="max-width: 100%;">
      </div></div>
      <div class="col-md-4" id="con2"  >
        <div class="text-center">
            <i id="ic" class="fa fa-heart" aria-hidden="true"></i>
            <h3 style="font-size: 25px;font-family: 'Simonetta';font-weight:bolder;">Satisfied Customers</h3>
        <p style="text-align: justify;"> Our work is giving satisfaction to our customers. There is a trustworthy relationship between our customers and us.</p>
        <img src="images/hr.png" alt="" style="max-width: 100%;"></div>
    </div>
     
    <div class="col-md-4 " id="con3" >
         <div class="text-center ">
            <i id="ic" class="fa fa-users" aria-hidden="true"></i> <h3 style="font-size: 25px;font-family: 'Simonetta';font-weight:bolder;">Energetic Team</h3>
        <p style="text-align: justify;">We have different members for different tasks and they are excited  for their work.So it leads to a splendid work.</p>
        <img src="images/hr.png" alt="" style="max-width: 100%;">
      </div></div>
    
</div>

<div class="container heading" style="margin-top:10px;">
    <div class="col-md-4" >
        <div class="text-center ">
            <i id="ic" class="fa fa-paper-plane" aria-hidden="true"></i> <h3 style="font-size:25px;font-family: 'Simonetta';font-weight:bolder;" > Switch Your offline Business into Online </h3>
        <p style="text-align: justify;">Today's Age is of internet.Every small task is happening with a click and it is very easy to handle the customers with this.So add the value into your business by switching offline business to online. </p>
        <img src="images/hr.png" alt="" style="max-width: 100%;">
    </div></div>
    <div class="col-md-4">
        <div class="text-center ">
            <img  class="thumbnail" src="images/r1.jpg" alt="" style="max-width: 100%;margin-top: 40px;">
            <img src="images/hr.png" alt="" style="max-width: 100%;margin-top: 10px;">
         </div>
    </div>
    <div class="col-md-4">
        <div class="text-center ">
            <i id="ic" class="glyphicon glyphicon-question-sign" ></i>
            <h3 style="font-size: 25px;font-family: 'Simonetta';font-weight:bolder;">Are You Ready to play at a Big Platform?</h3>
            <p style="text-align: justify;"> Do you want to see your business at a big level ?
                Don't think so much , it is going to make your work easy. Let's come together to give your business a big platform.We are here to help you!</p>
            <img src="images/hr.png" alt="" style="max-width: 100%;">
        </div>
    </div>
</div>
  <div class="container heading">
    <div class="col-md-4 ">
        <div class="text-center " >
            <span id="ic"  class="fa fa-handshake-o" aria-hidden="true"></span >
             <h3 style="font-size: 25px;font-family: 'Simonetta';font-weight:bolder;"> Collabrate With Us</h3>
           <p style="text-align: justify;"> Members of our Team are friendly, knowledgeable, quick to respond and the services which we are providing you is cheaper and best in quality. Your choice will be preferred. </p>
           <img src="images/hr.png" alt="" style="max-width: 100%;">
        </div>
     </div>


<div class="col-md-4 ">
     <div class="text-center">
        <img  class="thumbnail" src="images/r2.jpg" alt="" style="max-width: 100%;margin-top: 35px;">
        <img src="images/hr.png" alt="" style="max-width: 100%;">
     </div>
 </div>
 <div class="col-md-4 ">
    <div class="text-center">
        <i  id="ic" class="glyphicon glyphicon-time"></i>
      <h3 style="font-family: 'Simonetta';font-weight:bolder;"> 24/7 Support</h3>
      <p style="text-align: justify;">We are always here to help you. Any kind Of Query will be solved as soon as possible. You can mail us your query at our official mail. Customer satisfication is our prime importance.</p>
      <img src="images/hr.png" alt="" style="max-width: 100%;">
    </div>
  </div>
  </div>
</div>
              </div>

          </div >
          <div class="container" style="height:auto;">

            
                <div class="well text-center" style="margin-top: 10px;">
                    <h1 class="" style="font-family: 'Tinos';font-size: 40px;">Our services</h1>
                <img src="images/hr.png" alt="" style="max-width: 100%;">
                </div>
                <div class="row">
                <div class="col-lg-3  text-center " style="height: auto; padding-top: 20px;padding-bottom: 20px;">
                <div class="w3-card-2 hov w3-hover-shadow" style="margin-bottom: 30px;">
                <a href="services.php#web"><img  src="images/6.jpg" alt="img" style="width: 100%;height:auto;"></a>
                <!-- <div id="over">
                    <h1>hii i am suraj ram</h1>
                </div> -->
                <a href="services.php#web">
                     <div class="caption" >
                  <h2 style="color: black;">Web Development</h2>
                </div>
             </a>
                </div>
                <div class="w3-card-2 hov w3-hover-shadow" >
                    <a href="services.php#app"> <img src="images/81.jpg" alt="img" style="width: 100%;height:auto;"></a>
                    <a href="services.php#app">
                    <div class="caption">
                        <h2 style="color: black;">Mobile App</h2>
                    </div> </a>
                    </div>
            </div>
                    <div class="col-lg-3 text-center"  style="height:  auto;  padding-top: 20px;padding-bottom: 20px;">
                        <div class=" w3-card-2 hov w3-hover-shadow" style="margin-bottom: 30px;">
                            <a href="services.php#dig"> <img src="images/51.jpg" alt="img" style="width: 100%;height:auto;"> </a>
                            <a href="services.php#dig">
                            <div class="caption">
                                <h2 style="color: black;">Digital Marketing</h2>
                            </div>
                            </a>
                            </div>
                            <div class=" w3-card-2 hov w3-hover-shadow">
                                <a href="services.php#data_a">  <img src="images/21.jpg" alt="img" style="width: 100%;height:auto;"> </a>
                                <a href="services.php#data_a">
                             <div class="caption">
                                    <h2 style="color: black;">Data Analysis</h2>
                                </div>
                            </a>
                                </div>
                    </div>
                           
                                    <div class="col-lg-3  text-center "  style="height:  auto; padding-top: 20px;padding-bottom: 20px;">
                                        <div class="w3-card-2 hov w3-hover-shadow" style="margin-bottom: 30px;">
                                            <a href="services.php#busi"> <img src="images/31.jpg" alt="img" style="width: 100%;height:auto;"> </a>
                                            <a href="services.php#busi">
                                            <div class="caption">
                                                <h2 style="color: black;">Business Survey</h2>
                                            </div> </a>
                                            </div>
                                            <div class="w3-card-2 hov w3-hover-shadow">
                                                <a href="services.php#data_m" > <img src="images/71.jpg" alt="img" style="width: 100%;height:auto;"> </a>
                                                <a href="services.php#data_m">
                                                <div class="caption">
                                                    <h2 style="color: black;">Data Management</h2>
                                                </div>
                                                </a>
                                                </div>
                                            </div>
                                                    <div class="col-lg-3  text-center"  style="height: auto; padding-top: 20px;padding-bottom: 20px;">
                                                        <div class="w3-card-2 hov w3-hover-shadow" style="margin-bottom: 30px;">
                                                            <a href="services.php#for"> <img src="images/6.jpg" alt="img" style="width: 100%;height:auto;"> </a>
                                                                <a href="services.php#for">
                                                         <div class="caption">
                                                                <h2 style="color: black;">Forecasting</h2>
                                                            </div>
                                                            </a>
                                                            </div>
                                                            <div class="w3-card-2 hov w3-hover-shadow">
                                                                <a href="services.php#pho"> <img src="images/p12.jpg" alt="img" style="width: 100%;height:auto;"> </a>
                                                                    <a href="services.php#pho">
                                                             <div class="caption">
                                                                    <h2 style="color: black;">Photoshop</h2>
                                                                </div>
                                                                </a>
                                                                </div>
                                  </div>
                                 
            </div>
              
                         </div>
                     <div class="text-center" >
                        <img src="images/hr.png" alt="" style="max-width: 100%;">
                      </div>
          <div class="container">
            <div style="margin-top: 20px;" >
              <div class="col-md-4 col-sm-6">
                  <div class="panel panel-default">
                      <div class="panel-heading text-center">
                          <i class="fa fa-trophy fa-4x" style="color:rgb(167, 61, 61);"></i>
                      </div>
                      <div class="panel-body text-center">
                          <h3 class="margin-bottom-10">Loyalty</h3>
                          
                      </div>
                  </div>
              </div>
                  <div class="col-md-4 col-sm-6">
                      <div class="panel panel-default">
                          <div class="panel-heading text-center">
                              <i class="fa fa-balance-scale fa-4x" style="color:rgb(167, 61, 61);"></i>
                          </div>
                          <div class="panel-body text-center">
                              <h3 class="margin-bottom-10">Economical</h3>
                             
                          </div>
                      </div>
                  </div>
                      <div class="col-md-4 col-sm-6">
                          <div class="panel panel-default">
                              <div class="panel-heading text-center">
                                  <i class="fa fa-clone fa-4x" style="color:rgb(167, 61, 61);"></i>
                              </div>
                              <div class="panel-body text-center">
                                  <h3 class="margin-bottom-10">Easy Process</h3>
                                  
                              </div>
                          </div>
                      </div>

      </div>
          </div>


</div>
<div id="content-bottom-border" >
</div>
