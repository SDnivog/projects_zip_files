    <div class="container headnav" id="header" style="width:100%">
    <img  src="images/logo3.png" alt="LOGO" id="logo" style="">
<div class="container-fluid ">
    <div class="w3-padding w3-display-right" id="mains" style="font-size: larger;">
       <ul class="list-unstyled list-inline text-center" id="main"  >
       <li ><a role="button" href="index.php" class="c01" id="header1" onclick="made(1)" > HOME </a> </li>
       <li ><a role="button" href="team.php" class="c01" id="header2"  style=" text-decoration: none;"> TEAM </a></li>
       <li ><a role="button" href="services.php" class="c01" id="header3" style=" text-decoration: none; " > SERVICES </a></li>
       <li ><a role="button" class="c01" href="#" id="header4" style=" text-decoration: none;"><span class="glyphicon glyphicon-log-in" ></span><span style="font-size:25px; font-weight: bold;"> / </span><span class="glyphicon glyphicon-user"></span></a></li>
            
    </ul>
  </div>
</div>
<div id="menu_bar">
    <a href="#"><span class="glyphicon glyphicon-menu-hamburger" id="menu" onclick="show()"></span></a>

</div>
    </div>

    </div>