 <div id="content3">
            <div class="hoimg2 w3-card-2 text-center">
              <div  class="w3-container w3-display-middle">
                  <h1 id="heasd">SERVICES</h1>
              </div>
              <img src="images/hr.png" alt="" style="max-width: 100%;">
                </div>
                <div>
                  <div class="service_circle container-fluid text-center">
                      <div class="service_circle_image ">
                        <img src="images/discipline.jpg" alt="webDevelopment" style=" height: 210px; border-radius:50%;">
              
                      </div>
              
                      <div class="service_circle_image ">
                        <img src="images/trust.jpg" alt="webDevelopment" style=" height: 210px; border-radius:50%;">
              
                      </div>
                      <div class="service_circle_image ">
                          <img src="images/brainpower.jpg" alt="webDevelopment" style=" height: 210px; border-radius:50%;">
              
                        </div>
                      <div class="service_circle_image ">
                        <img src="images/creative.jpg" alt="webDevelopment" style=" height: 210px; border-radius:50%;">
              
                      </div>
                      </div>
                      <div class="container" style="">
                          <div class="text-center service_content" style="padding: 20px;">
                          <h2 >TRANDO team continuously getting projects form different Businesses and helping them to improve their Bussiness at online platform</h2>
                          <h3 >To make you Business Hi-Tech and get an access at online Platform come with Us and play at a big level</h3>
                          <img src="photos/hr.png" alt="" style="max-width: 100%;">
              
                          </div>
              
              
                          </div>
              
                     <div id="web" style="margin-bottom:10px; ">
                      <div class="image left" style="background:linear-gradient(rgba(255, 212, 118, 0.8),rgba(78, 78, 78, 0.932));">
                          <img src="images/w5.jpg" alt="webDevelopment" >
                          <div class="service_image_content_left" id="service_left1">
                            <h1>Web Development</h1>
                          <h3>Website is a collection of interlinked web pages which share a single domain name and used for showing information of an organization or a group or an individual.</h3>
                        <button type="button" class="btn btn-success">Give Project</button>
                          </div>
                          </div>
                          <div class="white" >
                              <div class="text-center">
                                  <h3 style="font-size: 25px;">As, Now your are familier with the Website that what it is ?An Online platform is useful for your organization and it also help Your Customer to know about your organization and give them a glimpse of transparency and make a trustworthy relationship.
                                  </h3><h3>Some Of the terms that are used in web Development:-</h3>
                              </div>
              <h1 >Domain Name</h1>
              <h3>Domain Name is Your Wesite Name or also can be said that it is an address of website where Internet user can access your website. it is used with extensions, such as: .com , .in, .net and so on... </h3>
              <h1 >Web Hosting</h1> 
              <h3>Web Hosting is a type of Internet service that allows individual and Organizations to make their website accessible via the World wide Web.</h3>    
          </div>
          <div class="text-center">
              <img src="images/hr.png" alt="" style="max-width: 100%;">
          </div>
                     </div>
              
                     <div id="app" style="margin-bottom: 10px;">
                      <div class="image right" style=" background:linear-gradient(rgba(92,188,210,0.8),black);">
                          <img src="images/a1.jpg" alt="webDevelopment" >
                          <div class="service_image_content_right"  id="service_right1">
                            <h1>Android App </h1>
                          <h3>An Android app is a software application running on the Android platform. Because the Android platform is built for mobile devices, a typical Android app is designed for a smartphone or a tablet PC running on the Android OS.</h3>
                          <button type="button" class="btn btn-success">Give Project</button>
                          </div>
                          </div>
                          <div class="white text-center" >
              <h1 style="border-bottom: none;margin-bottom: 20px;">Further Details Will be uploaded soon.</h1>
              <img src="images/hr.png" alt="" style="max-width: 100%;">
                          </div>
                     </div>
              
                    <div id="data_m" style="margin-bottom: 10px;">
                      <div class="image left" style=" background:linear-gradient(rgba(10,71,101,1.0),black);">
                          <img src="images/datam.jpg" alt="webDevelopment" >
                          <div class="service_image_content_left" id="service_left2" >
                            <h1>Data Management </h1>
                          <h3> Data management is an administrative process that includes acquiring, validating, storing, protecting, and processing required data to ensure the accessibility, reliability, and timeliness of the data for its users. ... Data management software is essential, as we are creating and consuming data at unprecedented rates.</h3>
                          <button type="button" class="btn btn-success">Give Project</button>
                          </div>
                          </div>
                          <div class="white text-center">
                              <h1 style="border-bottom: none;margin-bottom: 20px;">Further Details Will be uploaded soon.</h1>
                              <img src="images/hr.png" alt="" style="max-width: 100%;">
                          </div>
                    </div>
              
                    <div id="busi" style="margin-bottom: 10px;">
                      <div class="image right" style=" background:linear-gradient(rgba(255,255,255,1.0),rgba(0,0,0,0.4));">
                          <img src="images/computing.jpg" alt="webDevelopment" >
                          <div class="service_image_content_right" id="service_right2" >
                            <h1>Business Survey </h1>
                          <h3>Data is any sequence of one or more symbols given meaning by specific act of interpretation. Data requires interpretation to become information. To translate data to information, there must be several known factors considered. The factors involved are determined by the creator of the data and the desired information.</h3>
                          <button type="button" class="btn btn-success">Give Project</button>
                          </div>
                          </div>
                          <div class="white text-center" >
                              <h1 style="border-bottom: none;margin-bottom: 20px;">Further Details Will be uploaded soon.</h1>
                              <img src="images/hr.png" alt="" style="max-width: 100%;">
                          </div>
                    </div>
              
                      <div id="data_a" style="margin-bottom: 10px;">
                          <div class="image left" style=" background:linear-gradient(rgba(2,143,214,0.9),rgba(0,94,172,1.0));">
                              <img src="images/ana1.jpg" alt="webDevelopment" >
                              <div class="service_image_content_left" id="service_left3">
                                <h1>Data Analysis </h1>
                              <h3>Data analysis is defined as a process of cleaning, transforming, and modeling data to discover useful information for business decision-making. The purpose of Data Analysis is to extract useful information from data and taking the decision based upon the data analysis.</h3>
                              <button type="button" class="btn btn-success">Give Project</button>
                              </div>
                              </div>
                              <div class="white text-center" >
                                  <h1 style="border-bottom: none;margin-bottom: 20px;">Further Details Will be uploaded soon.</h1>
                                  <img src="images/hr.png" alt="" style="max-width: 100%;">
                              </div>
                      </div>
              
                     <div id="pho" style="margin-bottom: 10px;">
                      <div class="image right" style=" background:linear-gradient(rgba(42,49,61,1.0),rgba(175,186,192,0.9),rgba(42,49,61,1.0));">
                          <img src="images/photos.jpg" alt="webDevelopment">
                          <div class="service_image_content_right" id="service_right3">
                            <h1>Photoshop </h1>
                          <h3> Photoshop is a critical tool for designers, web developers, graphic artists, photographers, and creative professionals. It is widely used for image editing, retouching, creating image compositions, website mockups, and adding affects.</h3>
                          <button type="button" class="btn btn-success">Give Project</button>
                          </div>
                          </div>
                          <div class="white text-center" >
                              <h1 style="border-bottom: none;margin-bottom: 20px;">Further Details Will be uploaded soon.</h1>
                              <img src="images/hr.png" alt="" style="max-width: 100%;">
                          </div>
                     </div>
              
                     <div id="dig" style="margin-bottom:10px">
                      <div class="image left" style=" background:linear-gradient(rgba(251,180,10,1.0),rgba(251,181,0,0.9));">
                          <img src="images/d1.jpg" alt="webDevelopment" >
                          <div class="service_image_content_left" id="service_left4">
                            <h1>Digital Marketing </h1>
                          <h3>Digital marketing encompasses all marketing efforts that use an electronic device or the internet. Businesses leverage digital channels such as search engines, social media, email, and other websites to connect with current and prospective customers.</h3>
                          <button type="button" class="btn btn-success">Give Project</button>
                          </div>
                          </div>
                          <div class="white text-center" >
                              <h1 style="border-bottom: none;margin-bottom: 20px;">Further Details Will be uploaded soon.</h1>
                              <img src="photos/hr.png" alt="" style="max-width: 100%;">
                          </div>
                     </div>
              
                     <div id="for" style="margin-bottom: 10px;">
                      <div class="image right" style=" background:linear-gradient(rgba(0,22,36,1.0),rgba(1,32,52,0.9));">
                          <img src="images/forcast.jpg" alt="webDevelopment" >
                          <div class="service_image_content_right" id="service_right4">
                            <h1>Forecasting</h1>
                          <h3>Forecasting is something that make predictions of the future based on past and present data and most commonly by analysis of trends with the help of different methods. You can Consider the example of Weather prediction. Prediction is a similar, but more general term.</h3>
                          <button type="button" class="btn btn-success">Give Project</button>
                          </div>
                          </div>
                          <div class="white text-center">
                              <h1 style="border-bottom: none;margin-bottom: 20px;">Further Details Will be uploaded soon.</h1>
                              <img src="images/hr.png" alt="" style="max-width: 100%;">
                          </div>
              
                     </div>
              </div>
              
          </div>
          <div id="content-bottom-border" >
        </div>