

<div id="content2">
        <div class="hoimg1 w3-card-2 text-center">
            <div  class="w3-container w3-display-middle " style="margin-top: 70px;">
                <h1 id="heasd1" >OUR TEAM</h1>
            </div>
            <img src="images/hr.png" alt="" style="max-width: 100%;">
              </div>
        <div class="container-fluid" style="background-color: rgb(255, 255, 255);">
            <!--Cast Here the deatils of Feature-->
      <div class="text-center" style="padding: 60px;">
        <h2 class="text-center  " style="font-family: 'Martel';" >People Who are currently working in Trando and Giving Their Services.</h2>
        <h3 class="text-center" style="font-family: 'Tinos';">People to whom you are going to meet are very Energitic and dedicated for their Work</h3>
        <img src="images/hr.png" alt="" style="max-width: 100%;">
    
      </div>
      <div class="container our_team" >
        <section class="row container-fluid"  >
            <div class="text-center">
                <p class="" style="font-size:50px;padding:-10px;font-family: 'Overlock';">Our Team</p>
            <div class="col-lg-4 member" style="padding: 60px;">
    <img class=""  src="images/Dhanwant1.jpeg" alt="Dhanwantpal Singh" >
    <div class="title1">
    <!-- <h2>Founder and CEO</h2>  -->
    <a href="#"><span class="fa fa-facebook-square fb"></span></a><a href="#"><span class="fa fa-instagram ins" ></span></a><a href="#"><span class="fa fa-linkedin-square in" ></span></a><a href="#"><span class="fa fa-twitter tw" ></span></a>
    <h3>Dhanwantpal Singh</h3>
    </div>
    </div>
    <div  class="col-lg-4 member" style="padding: 60px;">
        <img   src="images/Gaurav1.jpeg" alt="Gaurav Jindal"  >
        <div class="title1">
         
         <a href="https://www.facebook.com/gaurav.jindal.16547"><span class="fa fa-facebook-square fb"></span></a><a href="#"><span class="fa fa-instagram ins" ></span></a><a href="#"><span class="fa fa-linkedin-square in" ></span></a><a href="#"><span class="fa fa-twitter tw" ></span></a>
        <h3>Gaurav Jindal</h3>
        </div>
        </div>
    
        <div class="col-lg-4 member" style="padding: 60px;">
        <img   src="images/suraj.jpeg" alt="Suraj Ram" >
        <div class="title1">
       
         <a href="https://www.facebook.com/suraj.ram.3532507"><span class="fa fa-facebook-square fb"></span></a><a href="#"><span class="fa fa-instagram ins" ></span></a><a href="#"><span class="fa fa-linkedin-square in" ></span></a><a href="#"><span class="fa fa-twitter tw" ></span></a>
        <h3>Suraj Ram</h3>
        </div>
        </div>
        <div class="col-lg-4 member" style="padding: 60px;">
        <img   src="images/govind.jpg" alt="govind" >
        <div class="title1">
       
         <a href="#"><span class="fa fa-facebook-square fb"></span></a><a href="#"><span class="fa fa-instagram ins" ></span></a><a href="https://www.linkedin.com/in/govind-suman-b900b5174/"><span class="fa fa-linkedin-square in" ></span></a><a href="#"><span class="fa fa-twitter tw" ></span></a>
        <h3>GOVIND</h3>
        </div>
        </div>
    </section>
    <section class="row container-fluid"  >
        <div class="col-lg-4 member" >
            <!-- <img   src="photos/Dhanwant.jpeg" alt="" >
            <div class="title1">
             <h2>Founder and CEO</h2> 
            <h4>Dhanwantpal Singh</h4>
            </div> -->
            </div>
            <div class="col-lg-4  member" style="padding-left: 60px;padding-right: 60px;">
                <img   src="images/ajay.jpeg" alt="Ajay Kumar" >
                <div class="title1">
                 
                 <a href="https://www.facebook.com/profile.php?id=100026698096994"><span class="fa fa-facebook-square fb"></span></a><a href="https://instagram.com/aj_arix?igshid=hyfugbi4fp0l"><span class="fa fa-instagram ins" ></span></a><a href="#"><span class="fa fa-linkedin-square in" ></span></a><a href="#"><span class="fa fa-twitter tw" ></span></a>
                <h3>Ajay Kumar</h3>
                </div>
                </div>
            <div class="col-lg-4  member" >
                <!-- <img   src="photos/Dhanwant.jpeg" alt="" >
                <div class="title1">
               <h2>Founder and CEO</h2> 
                <h4>Dhanwantpal Singh</h4>
                </div> -->
                </div>
            </section>
            <section class="row container-fluid"  >
                <div class="col-lg-2 member" style="padding-left: 60px;padding-right: 60px;">
                    <!-- <img   src="photos/suraj.jpeg" alt="" >
                    <div class="title1">
                    
                     <a href="#"><span class="fa fa-facebook-square fb"></span></a><a href="#"><span class="fa fa-instagram ins" ></span></a><a href="#"><span class="fa fa-linkedin-square in" ></span></a><a href="#"><span class="fa fa-twitter tw" ></span></a>
                    <h3>Shubham Pandey</h3>
                    </div> -->
                    </div>
                                <div class="col-lg-4 member" style="padding: 60px;">
                    <img class=""  src="images/devansh.jpeg" alt="Devansh Shrama" >
                    <div class="title1">
                   
                    <a href="#"><span class="fa fa-facebook-square fb"></span></a><a href="#"><span class="fa fa-instagram ins" ></span></a><a href="#"><span class="fa fa-linkedin-square in" ></span></a><a href="#"><span class="fa fa-twitter tw" ></span></a>
                    <h3>Devansh Shrama</h3>
                    </div>
                    </div>
                    <div  class="col-lg-4 member" style="padding: 60px;">
                        <img   src="images/nitish.jpeg" alt="Nitish Kumar"  >
                        <div class="title1">
                        
                         <a href="#"><span class="fa fa-facebook-square fb"></span></a><a href="#"><span class="fa fa-instagram ins" ></span></a><a href="#"><span class="fa fa-linkedin-square in" ></span></a><a href="#"><span class="fa fa-twitter tw" ></span></a>
                        <h3>Nitish Kumar</h3>
                        </div>
                        </div>
                    
                        <div class="col-lg-2 member" style="padding-left: 60px;padding-right: 60px;">
                        <!-- <img   src="photos/suraj.jpeg" alt="" >
                        <div class="title1">
                        
                         <a href="#"><span class="fa fa-facebook-square fb"></span></a><a href="#"><span class="fa fa-instagram ins" ></span></a><a href="#"><span class="fa fa-linkedin-square in" ></span></a><a href="#"><span class="fa fa-twitter tw" ></span></a>
                        <h3>Shubham Pandey</h3>
                        </div> -->
                        </div></div>
        </section>
        <div class="text-center">
            <img src="images/hr.png" alt="" style="max-width: 100%;margin-bottom: 10px;">
        </div>
      <!--  <div class="container" style="margin-bottom: 20px;">-->
      <!--    <h3 class="text-center" style="font-family: 'Overlock';">Other People Working in Trando </h3>-->
      <!--  <div class="text-center">-->
      <!--      <span   class=" other_people"><img class="thumbnail" src="photos/1.jpg" alt="" style="max-height: 100px;" ></span>-->
      <!--      <span   class=" other_people"><img class="thumbnail" src="photos/w3.jpg" alt=""  style="max-height: 100px;"></span>-->
      <!--      <span   class=" other_people"><img class="thumbnail" src="photos/1.jpg" alt=""  style="max-height: 100px;"></span>-->
      <!--      <span   class=" other_people"><img class="thumbnail" src="photos/w3.jpg" alt="" style="max-height: 100px;"></span>-->
      <!--      <span   class=" other_people"><img class="thumbnail" src="photos/1.jpg" alt="" style="max-height: 100px;"></span>-->
      <!--      <span   class=" other_people"><img class="thumbnail" src="photos/1.jpg" alt="" style="max-height: 100px;"></span>-->
      <!--      <span class=" other_people"><img class="thumbnail" src="photos/w3.jpg" alt="" style="max-height: 100px;"></span>-->
      <!--      <span class=" other_people"><img class="thumbnail" src="photos/1.jpg" alt="" style="max-height: 100px;"></span>-->
      <!--      <span class=" other_people"><img class="thumbnail" src="photos/w3.jpg" alt="" style="max-height: 100px;"></span>-->
      <!--      <span class=" other_people"><img class="thumbnail" src="photos/1.jpg" alt="" style="max-height: 100px;"></span>-->
      <!--      <span class=" other_people"><img class="thumbnail" src="photos/1.jpg" alt="" style="max-height: 100px;"></span>-->
      <!--      <span class=" other_people"><img class="thumbnail" src="photos/1.jpg" alt="" style="max-height: 100px;"></span>-->
      <!--   </div>-->
      <!--</div>-->
      </div>
      </div>
    </div>
    
