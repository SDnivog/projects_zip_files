<?php require_once("include/config.php"); ?>

<?php 

function Redirect_to($New_location){
	header("Location:".$New_location);
	exit();
}

// Function for login Required 

function Confirm_password(){
	if (isset($_SESSION["UserId"])) {
		return true;
	}else{
		$_SESSION["ErrorMessage"] = "Login Required";
		Redirect_to("../login.php");
	}
}



// // Function for User Login from Existing username and password
// function Login_Attampt($UserName,$Password){

// 		global $ConnectingDB;
// 		$sql = "SELECT * FROM   users WHERE username=:Username AND password=:Password LIMIT 1";
// 		$stmt = $ConnectingDB->prepare($sql);
// 		$stmt->bindValue(':Username',$UserName);
// 		$stmt->bindValue(':Password',$Password);
// 		$stmt->execute();
// 		$Result = $stmt->rowcount();
// 		if ($Result==1) {
// 			return $Found_Account=$stmt->fetch();
// 		}else{
// 			return null;
// 		}
// }

?>