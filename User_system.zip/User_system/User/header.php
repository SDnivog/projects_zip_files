<nav class="navbar navbar-expand-lg navbar-light bg-dark py-3" style="font-weight: bold;">
  <a class="navbar-brand text-light" href="index.php">Trando</a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>

  <div class="collapse navbar-collapse " id="navbarSupportedContent">
    <ul class="navbar-nav mr-auto">
      <li class="nav-item active"><a class="nav-link text-light" href="index.php"><i class="fas fa-home" ></i> Home <span class="sr-only">(current)</span></a></li>
      <li class="nav-item"><a class="nav-link text-light" href="index.php"><i class="fas fa-folder" ></i> Posts</a></li>
      <li class="nav-item"><a class="nav-link text-light" href="../index.php"><i class="fas fa-folder" ></i> Show All Posts</a></li>
      <li class="nav-item"><a class="nav-link text-light" href="insert.php"><i class="fas fa-upload" ></i> Upload</a></li>

      <!-- <li class="nav-item dropdown"><a class="nav-link dropdown-toggle text-light" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Dropdown</a>
        <div class="dropdown-menu" aria-labelledby="navbarDropdown">
          <a class="dropdown-item" href="#">Action</a>
           <div class="dropdown-divider"></div>
          <a class="dropdown-item" href="#">Another action</a>
          <div class="dropdown-divider"></div>
          <a class="dropdown-item" href="#">Something else here</a>
        </div>
      </li> -->
    </ul>
    <ul class="navbar-nav ml-auto">
      <li class="nav-item"><a href="logout.php"><i class="fas fa-user-times text-danger">&nbsp;Logout</i></a></li>
    </ul>
   <!--  <form class="form-inline my-2 my-lg-0">
      <input class="form-control mr-sm-2" type="search" placeholder="Search" aria-label="Search">
      <button class="btn btn-outline-success my-2 my-sm-0 bg-success text-light" type="submit">Search</button>
    </form> -->
  </div>
</nav>