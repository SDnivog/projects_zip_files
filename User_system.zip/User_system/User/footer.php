<footer class="bg-dark text-white py-5" >
	<div class="container">
		<div class="row">
			<div class="col">
			<p class="lead text-center">Theme by | GOVIND |<span id="year"></span> &copy; .....All right Reserved By <span><a href="index.php">Trando Pvt Ltd</a></span></p>
		</div>
		</div>
	</div>
</footer>