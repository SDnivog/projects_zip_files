<?php require_once("include/Function.php"); ?>
<?php require_once("include/Session.php"); ?>
<?php require_once("include/config.php"); ?>

<?php Confirm_password();  ?>

<?php 

    $_SESSION["UserId"]=null;
    $_SESSION["Username"]= null;
    $_SESSION["Password"]= null;
  
  session_destroy();
  Redirect_to("../index.php");
    



 ?>