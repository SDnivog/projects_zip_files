<?php require_once("include/config.php"); ?>
<?php require_once("include/Function.php"); ?>
<?php require_once("include/Session.php"); ?>

<?php Confirm_password();  ?>

<?php 

if (isset($_POST['Submit'])) {
  $Title = $_POST["title"];
  $Admin = $_SESSION["Username"];
 //$Admin = "GOVIND";
  $Text = $_POST["info"];
  $Website = $_POST["website"];
  $SName = $_POST["sem"];
  $Image = $_FILES['Image']['name'];
  $Target = "Upload/".basename($_FILES['Image']['name']);
  date_default_timezone_set("Asia/Kolkata"); //You can chage time Zone As you wish
  $CurrentTime = time();
  $DateTime = strftime("%B-%d-%Y  %H: %M: %S",$CurrentTime);


  if (empty($Title)) {
    
    $_SESSION["ErrorMessage"] = "Please fill information title !";
    Redirect_to("insert.php");
  }elseif (empty($Text)) {
    $_SESSION["ErrorMessage"] = "Please fill information description !";
    Redirect_to("insert.php");
  }elseif (empty($SName)) {
    $_SESSION["ErrorMessage"] = "Please choose semester name !";
    Redirect_to("insert.php");
  }

  else{

    #Query to insert post in DB when everything is fine
    global $ConnectingDB; // FOR OLD VERSION OF PHP LIKE 5.6 ect
    $sql = "INSERT INTO  info(datetime,title,author,text,website,sname,pdf)";
    $sql .= "VALUES(:DateTime,:TitlE,:AuthoR,:TexT,:WebsitE,:SnamE,:PdF)";
    $stmt = $ConnectingDB->prepare($sql);
    $stmt->bindValue(':DateTime',$DateTime);
     $stmt->bindValue(':TitlE',$Title);
      $stmt->bindValue(':AuthoR',$Admin);
       $stmt->bindValue(':TexT',$Text);
        $stmt->bindValue(':WebsitE',$Website);
         $stmt->bindValue(':SnamE',$SName);
          $stmt->bindValue(':PdF',$Image);
    
        $Execute =$stmt->execute();
         
        move_uploaded_file($_FILES["Image"]["tmp_name"], $Target);

        if ($Execute) {
          $_SESSION["SuccessMessage"] = "Information uploaded Successfully";
          Redirect_to("insert.php"); // You Can Send Admin to Any PAge YOU Want
        }else{
          $_SESSION["ErrorMessage"] = "Something Went to Wrong! Try Again!";
        Redirect_to("insert.php");
        }
  }

}// Ending of Submit button if-Condition


 ?>

<!DOCTYPE html>
<html>
<head>
	
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
	<script src="https://kit.fontawesome.com/96ab48350d.js" crossorigin="anonymous"></script>
	<title>Website</title>
	<style type="text/css">
		*{
			font-family: 'Righteous', cursive;
            font-family: 'Crete Round', serif;
		}
		table {
  font-family: arial, sans-serif;
  border-collapse: collapse;
  width: 100%;
}

td, th {
  border: 1px solid #dddddd;
  text-align: left;
  padding: 8px;
}

tr:nth-child(odd) {
  background-color: #dddddd;
}
.tab-pane h2,h4{
	font-weight: bold;
}
.tab-pane ol{
	font-weight: bold;
}
.border-box{
	border: 1px solid black;background: #dddddd;
}
.border-box h4{
	margin-left: 20px;
	font-weight: bold;
}
	</style>

</head>
<body>
	<!-- HEADER -->
	<?php include('header.php') ?>
	<!-- HEADER -->

<!-- MAIN SECTION START HERE-->
<div class="container-fluid mt-2">
	<div class="row">
		<div class="col-lg-12">

	 <form action="insert.php" method="post" enctype="multipart/form-data">  <!--  Here we using enctype in form this use for handle images in database table   -->
           <div class="card bg-dark text-light mb-3">
            <h3 class="bg-dark text-light py-3" style="font-weight: bold;">Upload notes/information for chemical department's students</h3>
             <?php 
                  echo ErrorMessage();
                  echo SuccessMessage(); 

       ?>
          <div class="card-body bg-secondary text-dark">
            <div class="form-group">
             <label for="title" class="head">Enter Information Title :</label>
              <input type="text" name="title" id="title" class="form-control" placeholder="Enter name here">
            </div>
            <div class="form-group">
              <label for="title1" class="head">Add Website link (If have any)</label>
              <input type="text" name="website" id="title1" class="form-control" placeholder="Add website link">
            </div>
            <div class="form-group">
              <label for="semn"> <span class="Fieldinfo">Choose Semester</span></label>
              <select class="form-control" id="semn" name="sem">
                 <option>4th Sem</option>
              </select>
            </div>
            <div class="form-group">
                <p class="small text-danger">Only .pdf,.dox files are allowed</p>
              <div class="custom-file">

              <input class="custom-file-input" type="File" name="Image" id="imageSelect">
              <label for="imageSelect" class="custom-file-label">Upload file</label>
              </div>
            </div>
            <div class="form-group">
              <label for="Post"> <span class="Fieldinfo">Describe about information :</span></label>
              <textarea name="info" rows="5" cols="40" class="form-control" id="Post"></textarea>
            </div>
            <div class="row">
              <!--
              <div class="col-lg-6 mb-2">
                <a href="Dashboard.php" class="btn btn-warning btn-block"><i class="fas fa-arrow-left"></i>Back To Dashboard</a>
              </div> -->
              <div class="col-lg-12 mb-2">
                <button type="submit" name="Submit" class="btn btn-warning btn-block">
                  <i class="fas fa-check"></i>Publish
                </button>
              </div>
            </div>
          </div>
        </div>
      </form>
</div>
	</div>
</div>
<!-- MAIN SECTION ENDING HERE -->

<!-- FOOTER STARTING -->
<?php include('footer.php') ?>
<!--FOOTER END-->
<!--- Bootsstrap js  --->
<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>

<!-- SCRIPT FOR COPYRIGHT YEAR -->
<script>
	$('#year').text(new Date().getFullYear());
</script>
</body>
</html>