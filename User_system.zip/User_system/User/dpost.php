
<?php require_once("include/config.php"); ?>
<?php require_once("include/Function.php"); ?>
<?php require_once("include/Session.php"); ?>

<?php Confirm_password();  ?>

<?php 

if (isset($_GET["id"])) {
  $SearchQueryParameter = $_GET["id"];

  global $ConnectingDB; // FOR OLD VERSION OF PHP LIKE 5.6 ect
  $AdminName = $_SESSION["Username"];
  $sql = "DELETE FROM  info  WHERE id='$SearchQueryParameter' AND author = '$AdminName' ";
  $Execute = $ConnectingDB->query($sql);
  if ($Execute) {
    
    $_SESSION["SuccessMessage"] = "Post Deleted SuccessFully ! ";
      Redirect_to("index.php");
  }
  else{
    $_SESSION["ErrorMessage"] = "Something Went to wrong. Try Again !";
      Redirect_to("index.php");
  }
}





 ?>