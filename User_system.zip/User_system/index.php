<?php require_once("include/config.php"); ?>
<?php require_once("include/Function.php"); ?>
<?php require_once("include/Session.php"); ?>




<!DOCTYPE html>
<html>
<head>
	
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
	<script src="https://kit.fontawesome.com/96ab48350d.js" crossorigin="anonymous"></script>
	<title>Website</title>
	<style type="text/css">
		*{
			font-family: 'Righteous', cursive;
            font-family: 'Crete Round', serif;
		}
		table {
  font-family: arial, sans-serif;
  border-collapse: collapse;
  width: 100%;
}

td, th {
  border: 1px solid #dddddd;
  text-align: left;
  padding: 8px;
}

tr:nth-child(odd) {
  background-color: #dddddd;
}
.tab-pane h2,h4{
	font-weight: bold;
}
.tab-pane ol{
	font-weight: bold;
}
.border-box{
	border: 1px solid black;background: #dddddd;
}
.border-box h4{
	margin-left: 20px;
	font-weight: bold;
}
	</style>

</head>
<body>
	<!-- HEADER -->
	<?php include('header.php') ?>
	<!-- HEADER -->

<!-- MAIN SECTION START HERE-->
<div class="container">
	<div class="row">
		<div class="col-lg-12 mt-4" style="overflow: auto;">
      <h2 class="bg-dark text-light py-3" style="font-weight: bold;">&nbsp;&nbsp;All Uploaded Information</h2>
			<?php 
                  echo ErrorMessage();
                  echo SuccessMessage(); 

       ?>
      <table class="table table-striped table-hover" >
        <thead class="thead-dark">
          <tr>
            <th>SrNo.</th>
            <th>DateTime</th>
            <th>Title</th>
            <th>Added_By</th>
            <th>Website</th>
            <th>Semester</th>
            <th>Description</th>
            <th>Uploaded Files</th>
          </tr>
        </thead>

      <!--- Php for Fetchin comments from database -->
      <?php 

      // if (isset($_GET["SearchButton"])) {
                
      //           $Search = $_GET["Search"];
      //           $sql = "SELECT * FROM info WHERE title LIKE :search OR author LIKE :search OR sname LIKE :search ";
      //           $stmt = $ConnectingDB->prepare($sql);
      //           $stmt->bindValue(':search','%'.$Search.'%');
      //           $stmt->execute();
      //         }
              
      //         //global $ConnectingDB;
      //   else{
      //         global $ConnectingDB;
      //         $sql = "SELECT * FROM info ORDER BY id desc ";
      //         $Execute = $ConnectingDB->query($sql);

      //       }
             global $ConnectingDB;
              $sql = "SELECT * FROM info ORDER BY id desc ";
              $Execute = $ConnectingDB->query($sql);
              $SrNo = 0;
              while ($DataRows=$Execute->fetch()) {
                
                 $AdminId = $DataRows["id"];
                 $DateTime = $DataRows["datetime"];
                 $Title = $DataRows["title"];
                 $Admin = $DataRows["author"];
                 $Website = $DataRows["website"];
                 $SName = $DataRows["sname"];
                 $Text = $DataRows["text"];
                 $Image = $DataRows["pdf"];
                 $SrNo++;
                 
       ?>
       <tbody>
        <tr>
          <td><?php echo htmlentities($SrNo) ; ?></td>
          <td><?php echo htmlentities($DateTime) ; ?></td>
          <td><?php echo htmlentities($Title) ; ?></td>
          <td><?php echo htmlentities($Admin) ; ?></td>
          <td><a href="<?php echo htmlentities($Website) ; ?>"><?php echo htmlentities($Website) ; ?></a></td>
          <td><?php echo htmlentities($SName) ; ?></td>
          <td><?php echo htmlentities($Text) ; ?></td>
          <td><a href="User/Upload/<?php echo htmlentities($Image) ; ?>"><?php echo htmlentities($Image) ; ?></a></td>
         <!-- <td><a href="Dpost.php?id=<?php echo $AdminId; ?>" class="btn btn-danger">Delete</a></td>-->
        </tr>
       </tbody>
      <?php } ?>
      </table>
		</div>
	</div>
</div>
<!-- MAIN SECTION ENDING HERE -->

<!-- FOOTER STARTING -->
<?php include('User/footer.php') ?>
<!--FOOTER END-->
<!--- Bootsstrap js  --->
<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>

<!-- SCRIPT FOR COPYRIGHT YEAR -->
<script>
	$('#year').text(new Date().getFullYear());
</script>
</body>
</html>