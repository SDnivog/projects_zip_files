<?php require_once("include/config.php"); ?>
<?php require_once("include/Function.php"); ?>
<?php require_once("include/Session.php"); ?>




<?php 
 // Yah  1st Wali IF Condition iss liye use ki hai Agr user logged in hai to wo login page prr nahi aa sakta hai
if (isset($_SESSION["UserId"])) {     
    Redirect_to("index.php");
}


if (isset($_POST['Login'])) {
    
    $UserName = $_POST["username"];
    $Password = $_POST["password"];

    if (empty($UserName)||empty($Password)) {
        $_SESSION["ErrorMessage"] = "Please enter username and password";
        Redirect_to("login.php");
    }else{

        // code for checking username and password from database
        $Found_Account=Login_Attampt($UserName,$Password);
        if ($Found_Account) {
        
           $_SESSION["UserId"]= $Found_Account["id"];
            $_SESSION["Username"]= $Found_Account["username"];
           $_SESSION["Password"]= $Found_Account["password"];
           

            $_SESSION["SuccessMessage"] = "Welcome " .$_SESSION["Username"]. " !";
            Redirect_to("User/index.php");
        }else{
            $_SESSION["ErrorMessage"] = "Incorrect Username and Password";
            Redirect_to("login.php");
        }
    
    }
}



 ?>


<!DOCTYPE html>
<html>
<head>
	
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
	<script src="https://kit.fontawesome.com/96ab48350d.js" crossorigin="anonymous"></script>
	<title>Website</title>
	<style type="text/css">
		*{
			font-family: 'Righteous', cursive;
            font-family: 'Crete Round', serif;
		}
		table {
  font-family: arial, sans-serif;
  border-collapse: collapse;
  width: 100%;
}

td, th {
  border: 1px solid #dddddd;
  text-align: left;
  padding: 8px;
}

tr:nth-child(odd) {
  background-color: #dddddd;
}
.tab-pane h2,h4{
	font-weight: bold;
}
.tab-pane ol{
	font-weight: bold;
}
.border-box{
	border: 1px solid black;background: #dddddd;
}
.border-box h4{
	margin-left: 20px;
	font-weight: bold;
}
	</style>

</head>
<body>
	<!-- HEADER -->
	<?php include('header.php') ?>
	<!-- HEADER -->

<!-- MAIN SECTION START HERE-->
<div class="container mt-5">
	<div class="row">
		<div class="col-lg-12">
	<form action="login.php" method="post" class="" >
		<div class="card mb-3">
        <div class="card-header bg-primary text-light">
        	<h5 class="Fieldinfo">Please fill your following details</h5>
        </div>
        <?php 
                  echo ErrorMessage();
                  echo SuccessMessage(); 

       ?>
        <div class="card-body">
        	<div class="form-group">
        		<div class="input-group">
        			<div class="input-group-prepend">
        				<span class="input-group-text"><i class="fas fa-user">&nbsp;Username</i></span>
        			</div>
        		<input class="form-control" type="text" name="username" placeholder="Enter your college email id" value="" required="">
        		</div>
        	</div>
        		<div class="form-group">
        		<div class="input-group">
        			<div class="input-group-prepend">
        				<span class="input-group-text"><i class="fas fa-lock">&nbsp;Password</i></span>
        			</div>

        		<input class="form-control" type="password" name="password" placeholder="example.cm.18@nitj.ac.in" value="" required="">
        		</div>
        	</div>
        	<button class="btn btn-primary" type="submit" name="Login">Login</button>
        </div>
		</div>
	</form>
</div>
	</div>
</div>
<!-- MAIN SECTION ENDING HERE -->

<!-- FOOTER STARTING -->
<?php include('User/footer.php') ?>
<!--FOOTER END-->
<!--- Bootsstrap js  --->
<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>

<!-- SCRIPT FOR COPYRIGHT YEAR -->
<script>
	$('#year').text(new Date().getFullYear());
</script>
</body>
</html>