<?php 
$DSN ='mysql:host = localhost; dbname=chemical';  #NOT ADD any Space between dbname & '=' sign
$ConnectingDB = new PDO($DSN,'root','');

 ?>