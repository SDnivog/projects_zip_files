<?php require_once("include/config.php"); ?>
<?php require_once("include/Function.php"); ?>
<?php require_once("include/Session.php"); ?>

<?php 

if (isset($_GET["id"])) {
  $SearchQueryParameter = $_GET["id"];

  global $ConnectingDB; // FOR OLD VERSION OF PHP LIKE 5.6 ect
  //$Admin = $_SESSION["AdminName"];
  $sql = "DELETE FROM  edemo  WHERE id='$SearchQueryParameter' ";
  $Execute = $ConnectingDB->query($sql);
  if ($Execute) {
    
    $_SESSION["SuccessMessage"] = "Details Deleted SuccessFully ! ";
      Redirect_to("demo_respon.php");
  }
  else{
    $_SESSION["ErrorMessage"] = "Something Went to wrong. Try Again !";
      Redirect_to("demo_respon.php");
  }
}





 ?>