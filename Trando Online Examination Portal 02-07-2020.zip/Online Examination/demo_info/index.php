
<?php require_once("include/config.php"); ?>
<?php require_once("include/Function.php"); ?>
<?php require_once("include/Session.php"); ?>




<?php 

if (isset($_POST['Submit'])) {
  
  $Name = $_POST['Name'];
  $Email = $_POST['Email'];
  $Mobile = $_POST['MobileNo'];
  $RollNo = $_POST['RollNo'];

  //$Admin = $_SESSION["UseRName"]; # Using Dynamically By session variables
    date_default_timezone_set("Asia/Kolkata"); //You can chage time Zone As you wish
    $CurrentTime = time();
    $DateTime = strftime("%B-%d-%Y  %H: %M: %S",$CurrentTime);


  if (empty($Name)) {
    
    $_SESSION["ErrorMessage"] = "Enter your name !";
    Redirect_to("index.php");
  }elseif(CheckUserNameExistOrNot1($Email)) {
    
    $_SESSION["ErrorMessage"] = "Name Or Email already exist Try another !";
    Redirect_to("index.php");
  }
  else{

    #Query to insert post in DB when everything is fine
    global $ConnectingDB; // FOR OLD VERSION OF PHP LIKE 5.6 ect
    $sql = "INSERT INTO  edemo(datetime,name,email,mobile,rollno)";
    $sql .= "VALUES(:dateTime,:NamE,:EmaiL,:Mobile,:RollNo)";
    $stmt = $ConnectingDB->prepare($sql);
    $stmt->bindValue(':dateTime', $DateTime);
    $stmt->bindValue(':NamE', $Name);
    $stmt->bindValue(':EmaiL',$Email);
    $stmt->bindValue(':Mobile', $Mobile);
     $stmt->bindValue(':RollNo', $RollNo);
        $Execute =$stmt->execute();
        if ($Execute) {
          $_SESSION["SuccessMessage"] = "Response submitted Successfully user id and password for login sent to your register email";
          Redirect_to("index.php"); // You Can Send Admin to Any PAge YOU Want
        }else{
          $_SESSION["ErrorMessage"] = "Something Went to Wrong! Try Again!";
        Redirect_to("index.php");
        }
  }

}// Ending of Submit button if-Condition


 ?>


<!DOCTYPE html>
<html>
<head>
	
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
	<script src="https://kit.fontawesome.com/96ab48350d.js" crossorigin="anonymous"></script>
   <link href="../assets/images/icon.png" rel="icon">
	<title>Trando Online examination</title>
</head>
<body>

<div class="container mt-5">
	<div class="row">
		<div class="col-lg-12">
	<form action="index.php" method="post" class="" >
		<div class="card mb-3">
        <div class="card-header bg-info text-light">
        	<h5 class="text-center ">Please submit your details for demo</h5>
        </div>
        <?php 
                  echo ErrorMessage();
                  echo SuccessMessage(); 

       ?>
        <div class="card-body">
        	<div class="form-group">
        		<div class="input-group">
        			<div class="input-group-prepend">
        				<span class="input-group-text">Enter &nbsp;&nbsp;<i class="fas fa-user"></i></span>
        			</div>
        		<input class="form-control" type="text" name="Name" placeholder="Name" value="" required="">
        		</div>
        	</div>
          <!--   <small class="text-danger">Please enter college email id</small> -->
        		<div class="form-group">

        		<div class="input-group">
        			<div class="input-group-prepend">
        				<span class="input-group-text">Email&nbsp;&nbsp;<i class="fas fa-envelope"></i></span>
        			</div>

        		<input class="form-control" type="email" name="Email" placeholder="example@gmail.com" value="" required="">
        		</div>
        	</div>
        	<div class="form-group">
        		<div class="input-group">
        			<div class="input-group-prepend">
        				<span class="input-group-text">Mobile&nbsp;<i class="fas fa-mobile"></i></span>
        			</div>
        		<input class="form-control" type="number" name="MobileNo" placeholder="Mobile number..." value="" required="">
        		</div>
        	</div>
        	<div class="form-group">
        		<div class="input-group">
        			<div class="input-group-prepend">
        				<span class="input-group-text">DOB&nbsp;&nbsp;&nbsp;&nbsp;<i class="fas fa-calendar-day"></i></span>
        			</div>
        		<input class="form-control" type="date" name="RollNo" placeholder="Enter date of birth..." value="" required="">
        		</div>
        	</div>
        	<button class="btn btn-primary" type="submit" name="Submit">Submit</button>
        </div>
		</div>
	</form>
</div>
	</div>
</div>
<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>

</body>
</html>