<?php require_once("include/config.php"); ?>

<?php 

function Redirect_to($New_location){
	header("Location:".$New_location);
	exit();
}


// Follwing function for check Existing user
function CheckUserNameExistOrNot1($Email){
 global $ConnectingDB;
$sql = "SELECT name,email FROM edemo WHERE email = :EmaiL ";
$stmt = $ConnectingDB->prepare($sql);
// $stmt->bindValue(':userName',$Name);
$stmt->bindValue(':EmaiL',$Email);
$stmt->execute();
$Result = $stmt->rowCount();
if ($Result==1) {
	return true;
}else{
	return false;
    }
}

?>