<?php 
$DSN ='mysql:host = localhost; dbname=oes_db';  #NOT ADD any Space between dbname & '=' sign
$ConnectingDB = new PDO($DSN,'root','');

 ?>