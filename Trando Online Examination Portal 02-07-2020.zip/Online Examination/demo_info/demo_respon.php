
<?php require_once("include/config.php"); ?>
<?php require_once("include/Function.php"); ?>
<?php require_once("include/Session.php"); ?>



<!DOCTYPE html>
<html>
<head>
	
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
	<script src="https://kit.fontawesome.com/96ab48350d.js" crossorigin="anonymous"></script>
   <link href="../assets/images/icon.png" rel="icon">
	<title>Trando Online examination</title>
</head>
<body>

<div class="container mt-5">
	<div class="row">
		<div class="col-lg-12">
      <?php 
                  echo ErrorMessage();
                  echo SuccessMessage(); 

       ?>
      <h2 class="bg-secondary py-3 text-light">&nbsp;&nbsp;&nbsp;&nbsp;Registered users for demo</h2>
	<table class="table">
        <thead class="thead-dark table-striped table-hover">
        <tr>
          <th>#</th>
          <th>Date Time</th>
          <th>Name</th>
          <th>Email</th>
          <th>Mobile_No.</th>
          <th>DOB</th>
          <th>Action</th>
        </tr>
        </thead>
        <?php 
                
                 global $ConnectingDB; // FOR OLD VERSION OF PHP LIKE 5.6 ect
                 $sql = "SELECT * FROM  edemo ";
                 $stmt = $ConnectingDB->query($sql);

                 $Sr = 0;
                 while ($DataRows = $stmt->fetch()) { 
                  $Id  = $DataRows["id"];
                  $Date = $DataRows["datetime"];
                  $Name = $DataRows["name"];
                  $Email = $DataRows["email"];
                  $Mobile = $DataRows["mobile"];
                  $DOB = $DataRows["rollno"];
                  $Sr ++;
         ?>
         <tbody>
         <tr>
          <td><?php echo $Sr; ?></td>
          <td><?php echo htmlentities($Date); ?></td>
          <td><?php echo htmlentities($Name); ?></td>
          <td><?php echo htmlentities($Email); ?></td>
          <td><?php echo htmlentities($Mobile); ?></td>
          <td><?php echo htmlentities($DOB); ?></td>
          <td><a class="btn btn-danger" href="d_details.php?id=<?php echo $Id; ?>">Delete</a></td>
         </tr>
         </tbody>
        <?php } ?>
      </table>
</div>
	</div>
</div>
<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>

</body>
</html>